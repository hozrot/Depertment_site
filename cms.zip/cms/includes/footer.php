<footer class="container-fluid">
			<div class="container">
				<div class="row"  >
						<div class="col-sm-3" >
							<h4>Related Depertments</h4>
							<p class="footmanu"> 
								<a href="#">Math</a></br>
								<a href="#">Physics</a></br>
							</p>
							<h4>Other Depertments</h4>
							<p class="footmanu" > 
								<a href="#">Sociology</a></br>
								<a href="#">Managemant</a></br>
								<a href="#">English</a></br>
								<a href="#">Accounting</a></br>
								<a href="#">Statistic</a></br>
							</p>
						</div><!-- end col-sm-3 -->
							
						<div class="col-sm-3">
								<h4>Student Corners</h4>
								<p class="footmanu" > 
									<a href="#">Result</a></br>
									<a href="#">Course</a></br>
									<a href="#">Routine</a></br>
									<a href="#">Registration</a></br>
									<a href="#">Library</a></br>
								</p>
								<h4>Help Line</h4>
								<p class="footmanu" > 
									<a href="#">Office</a></br>
									<a href="#">Seminer Library</a></br>
									<a href="#">Lab</a></br>
									<a href="#">Medical Center</a></br>
									<a href="#">Math</a></br>
								</p>
								<h4> Admission</h4>
								<p class="footmanu" > 
									<a href="#">Notice</a></br>
									<a href="#">Prospectas</a></br>
								</p>
						</div><!-- end col-sm-3 -->
							
						<div class="col-sm-2">
								<h4>Research</h4>
								<p class="footmanu" > 
									<a href="#">Workshop</a></br>
									<a href="#">Seminer</a></br>
									<a href="#">Project</a></br>
									<a href="#">Contest</a></br>
									<a href="#">Thesis</a></br>
								</p>
						</div><!-- end col-sm-2 -->
							
						<div class="col-sm-4" align="right">
								<h2 >CSE BRUR</h2>
								 <blockquote class="footmanu"> Building no: 02 </br> 2nd floor </br> Parker more , lalbar, Rangpur</blockquote>
						</div><!-- end col-sm-4 -->

				</div><!-- end row -->
			</div><!-- end container -->
		</footer>