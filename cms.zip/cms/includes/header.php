 <!-- Header   -->

			<div class="header" id="header">
				<div class="container" id="header-content">
					 <h2 > BRUR | <small>Engineering</small></h2>
					 <a href="/" id="depertment"> Computer Science & Engineering</a> 	

						 <form class="form-inline pull-right">
							<input type="text" class="form-control" placeholder="Search this site..." id="searchInput">
							<button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
						</form><!-- end navbar-form -->


				</div>
			 	
			</div>
			<!-- end Header -->