<?php 
$con = mysqli_connect("localhost","ali","*963.","university_management");
if (!$con) {
	die("Can not connect Database " .mysqli_connect_error());
}
 
 ?>