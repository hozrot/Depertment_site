<div class="container-fluid">
		<div class="row" id="bottom-bar">
		<p class="copyright"> © 2009 Begum Rokeya University, Rangpur. All Rights Reserved(CSE, BRUR) </p>
		</div>
		<div class="social">
			 
				 
				 
				 <p class="icon" align="center">
						<a href="http://www.facebook.com">
						<img border="0" alt="Facebook" src="images/facebook.png" width="50" height="50">
						</a>
				 
	 
						<a href="http://www.twiteer.com">
						<img border="0" alt="twiteer" src="images/twiteer.png" width="50" height="50">
						</a>
				 
				 
						<a href="http://www.instagram.com">
						<img border="0" alt="instagram" src="images/instagram.png" width="50" height="50">
						</a>
					 
						<a href="http://www.youtube.com">
						<img border="0" alt="youtube" src="images/youtube.jpg" width="50" height="50">
						</a>
					 	<a href="http://www.google.com">
						<img border="0" alt="google" src="images/google-plus.png" width="50" height="50">
						</a>
						<a href="http://www.uva.com">
						<img border="0" alt="uva" src="images/uva.jpg" width="50" height="50">
						</a>
		        </p>

			 
		</div>
			
</div>