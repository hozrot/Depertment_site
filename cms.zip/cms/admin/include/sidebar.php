 
			<div class="col-lg-2 ">
				<ul class="navbar-default nav" style="height:650px">
					<li><a href="dashboard.php"><i class="glyphicon glyphicon-dashboard"></i> Dashboard</a></li>
					<li><a href="#add-members " data-toggle="collapse"><i class="glyphicon glyphicon-plus"></i> Add Members</a></li>
						<ul class="nav collapse" id="add-members">
							<li><a href="add-teacher.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-copy"></i>Teachers </a></li>
							<li><a href="add-student.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-option-vertical"></i> Students </a></li>
							<li><a href="add-office-staff.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-volume-up"></i> Office Staff </a></li>
						</ul>
					<li><a href="add-course.php"><i class="glyphicon glyphicon-option-vertical"></i> Add Course</a></li>
					<li><a href="add-banner.php"><i class="glyphicon glyphicon-option-vertical"></i> Add Banner</a></li>
				 
					<li><a href="#add-result " data-toggle="collapse"><i class="glyphicon glyphicon-plus"></i>Add Result</a></li>
						<ul class="nav collapse" id="add-result">
							<li><a href="result-admission.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-copy"></i>Admission </a></li>
							<li><a href="result-continious.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-option-vertical"></i> Continious </a></li>
							<li><a href="result-final.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-volume-up"></i> Final </a></li>
						</ul>
					<li><a href="events.php"><i class="glyphicon glyphicon-tags"></i> Events</a></li>
					<li><a href="notice.php"><i class="glyphicon glyphicon-edit"></i> Notice</a></li>
					<li><a href="#add-new " data-toggle="collapse"><i class="glyphicon glyphicon-plus"></i> Add New</a></li>
						<ul class="nav collapse" id="add-new">
							<li><a href="add-depertment.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-copy"></i>Add Depertment </a></li>
							<li><a href="add-designation.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon glyphicon-sunglasses"></i> Add Designation </a></li>
							<li><a href="add-accademic-year.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-copy"></i>Add Acca-year </a></li>
							<li><a href="add-hometown.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-option-vertical"></i> Add HomeTown  </a></li>
							<li><a href="add-hall.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-copy"></i>Add Hall </a></li>
							<li><a href="#add-content " data-toggle="collapse"><i class="glyphicon glyphicon-plus"></i>Add Content</a></li>
								<ul class="nav collapse" id="add-content">
									<li><a href="recent-news.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-copy"></i>Recent News </a></li>
									<li><a href="welcome-note.php"><div class="col-sm-2"></div><i class="glyphicon glyphicon-option-vertical"></i> Welcome Note </a></li>
									 
								</ul>
							 
						</ul>
				</ul>
			</div>
		                                             